from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import requests

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this in production to allow only specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/scopus")
def get_scopus_data(query: str):
    headers = {
        "X-ELS-APIKey": "f3d71c22cc04d7bc3a4ef5843fe17a6b"
    }
    scopus_url = f"https://api.elsevier.com/content/search/scopus?query={query}"
    response = requests.get(url=scopus_url, headers = headers)
    # print(response.text)
    return response.text


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)