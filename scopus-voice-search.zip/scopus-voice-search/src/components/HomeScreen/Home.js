import React, { useState } from 'react';
import { recognition } from '../../api/VoiceSearchAPI';
import Header from './Header';
import Footer from './Footer';
import logo from './img/els-logo.svg';
import scopus from './img/body-scopus.svg';
import voiceSearch from './img/body-voiceSearch.svg';
import './css/Home.css';
import VoiceSearchBox from './VoiceSearchBox';

const Home = ({ setSearch , setData }) => {
  const [term, setTerm] = useState('');
  const [isVoiceSearch, setIsVoiceSearch] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [isData, setIsData] = useState(false);
  const [resultsData, setResultsData] = useState([]);
  const getData = () => {
    if (setData.length) {
      setIsData(true);
      var searchData = JSON.parse(setData);
      setResultsData(searchData['search-results']['entry'])
      console.log(resultsData);
    }
    
  };

  const clearTerm = () => {
    setTerm('');
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (
      /^[a-zA-Z0-9].*/.test(term) ||
      /^[a-zA-Z0-9]+[" "]/.test(term) ||
      /^[" "]+[a-zA-Z0-9]/.test(term)
    ) {
      setSearch(term.trim());
    }
  };
  const handleSearch = () => {
    if (
      /^[a-zA-Z0-9].*/.test(term) ||
      /^[a-zA-Z0-9]+[" "]/.test(term) ||
      /^[" "]+[a-zA-Z0-9]/.test(term)
    ) {
      setSearch(term.trim());
    }
    getData();
  };
  const clearVoiceSearch = () => {
    setIsVoiceSearch(false);
    recognition.stop();
  };
  const openVoiceSearch = () => {
    setIsVoiceSearch(true);
    recognition.start();
    recognition.onresult = (event) => {
      var current = event.resultIndex;
      var transcript = event.results[current][0].transcript;
      setVoiceText(voiceText + transcript);
      setTerm(voiceText + transcript);
      setSearch(voiceText + transcript);
    };
  };
  return (
    <>
      {isVoiceSearch ? (
        <VoiceSearchBox
          voiceText={voiceText}
          clearVoiceSearch={clearVoiceSearch}
          openVoiceSearch={openVoiceSearch}
        />
      ) : null}
      <Header />
      <div className="container">
        <div className="row">
          <div className="col-md-12 home-screen align-items-center justify-content-center">
            <div className="img-home-con">
              <img
                src={logo}
                alt="Elsevier Logo"
                height={50}
                className="els-img els-logo-home"
              />
              <img
                src={scopus}
                alt="Elsevier Logo"
                height={20}
                className="els-img"
              />
              <img
                src={voiceSearch}
                alt="Elsevier Logo"
                height={20}
                className="els-img"
              />       
            </div>     
            <div className="search-box col-md-7 border d-flex py-2 justify-content-between align-items-center">
              <i className="fa fa-search" onClick={() => handleSearch()}></i>
              <form className="form-search" onSubmit={(e) => handleSubmit(e)}>
                <input
                  type="text"
                  name="term"
                  id="term"
                  value={term}
                  onChange={(e) => setTerm(e.target.value)}
                />
              </form>
              {term ? (
                <i className="fa fa-close" onClick={() => clearTerm()}></i>
              ) : (
                ''
              )}
              <i
                className="fa fa-microphone"
                onClick={() => openVoiceSearch()}></i>
            </div>
          </div>
        </div>
        {term ?(
          <table>
            <tbody>
              {isData ?(
                resultsData.map((result, i) => (
                  <tr key={i}>
                    <td>
                      <a href={result["link"][2]["@href"]}>{result["dc:title"]}</a>
                      <ul>
                        <li>
                            <div>
                                <div><span>{result["prism:aggregationType"]}</span></div>
                            </div>
                        </li>
                        <li>
                            <div>
                                <div><span>{result["prism:coverDisplayDate"]}</span></div>
                            </div>
                        </li>
                        <li>
                            <div>
                                <div><span>{result["prism:issn"]}</span></div>
                            </div>
                        </li>
                        <li>
                            <div>
                                <div><span>{result["prism:pageRange"]}</span></div>
                            </div>
                        </li>
                      </ul>
                    </td>
                    <td>{result["dc:creator"]}</td>
                  </tr>
                ))
              ) : null
              }
            </tbody>
          </table> ) : null
        }
      </div>
      <Footer />
    </>
  );
};

export default Home;
