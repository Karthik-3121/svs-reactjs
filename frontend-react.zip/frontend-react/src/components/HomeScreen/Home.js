import React, { useState, useEffect } from 'react';
import { recognition } from '../../api/VoiceSearchAPI';
import Header from './Header';
import Footer from './Footer';
import './css/Home.css';
import VoiceSearchBox from './VoiceSearchBox';

const Home = ({ setSearch, setData }) => {
  const [term, setTerm] = useState('');
  const [previousTerm, setPreviousTerm] = useState(''); // Track the previous search term
  const [isVoiceSearch, setIsVoiceSearch] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [isData, setIsData] = useState(false);
  const [resultsData, setResultsData] = useState([]);
  const [showTypingText, setShowTypingText] = useState(true); // State to control typing text visibility
  const [loading, setLoading] = useState(false); // Loading state to prevent no data message

  useEffect(() => {
    if (setData && setData.length) {
      setIsData(true);
      const searchData = JSON.parse(setData);
      setResultsData(searchData['search-results']['entry']);
      setLoading(false);  // Stop loading once data is fetched
    }
  }, [setData]);

  const clearTerm = () => {
    setTerm('');
  };

  const handleSearch = () => {
    if (term.trim() && term !== previousTerm) { // Only set loading if term is new or different
      setLoading(true);  // Set loading state before searching
      setPreviousTerm(term.trim()); // Update the previous term
      setSearch(term.trim());
      setResultsData([]); // Clear previous results before fetching new ones
      setShowTypingText(false); // Hide typing text when searching
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (term.trim() && term !== previousTerm) { // Only set loading if term is new or different
      setLoading(true);  // Set loading state before searching
      setPreviousTerm(term.trim()); // Update the previous term
      setSearch(term.trim());
      setResultsData([]); // Clear previous results before fetching new ones
      setShowTypingText(false); // Hide typing text when searching
    }
  };

  
  const openVoiceSearch = () => {
    setIsVoiceSearch(true);
    recognition.start();
    recognition.onresult = (event) => {
      const current = event.resultIndex;
      const transcript = event.results[current][0].transcript;
      setVoiceText(transcript);
      setTerm(transcript);
      setSearch(transcript); // Pass the transcript as the new search term
    };
  };
  const clearVoiceSearch = () => {
    setIsVoiceSearch(false);
    recognition.stop();
    setVoiceText('');
  };


  return (
    <>
      {isVoiceSearch ? (
        <VoiceSearchBox
          voiceText={voiceText}
          clearVoiceSearch={clearVoiceSearch}
          openVoiceSearch={openVoiceSearch}
        />
      ) : null}
      <Header />
      <div className={`container ${isData && resultsData.length > 0 ? 'reduce-space' : ''}`}>
        <div className="home-screen">
          {/* Conditionally Render Typing Animation or Search Box */}
          {showTypingText && (!isData || (isData && resultsData.length === 0)) ? (
            <div className="typing-text">Welcome to Scopus Please Search Here!</div>
          ) : null}
          <div className={`row ${isData && resultsData.length > 0 ? 'move-search-box-up' : ''}`}>
            <div className="col-md-12 align-items-center justify-content-center">
              <div className="search-box col-md-7 border d-flex py-2 justify-content-between align-items-center">
                <i className="fa fa-search search-icon" onClick={handleSearch}></i>
                <form className="form-search" onSubmit={handleSubmit}>
                  <input
                    type="text"
                    placeholder="Scopus Search"
                    name="term"
                    id="term"
                    value={term}
                    onChange={(e) => setTerm(e.target.value)}
                  />
                </form>
                {term ? (
                  <i className="fa fa-close" onClick={clearTerm}></i>
                ) : null}
                <i
                  className="fa fa-microphone"
                  onClick={openVoiceSearch}
                ></i>
              </div>
            </div>
          </div>

          {/* Show loading message when data is being fetched */}
          {loading && (
            <div className="loading-message">
              Please wait... <div className="loading-spinner"></div>
            </div>
          )}

          {/* Show "No Data" message only when not loading */}
          {resultsData.length === 1 && resultsData[0]['error'] === "Result set was empty" ? (
            <div className="no-data-message">
              <p>No documents matching your keywords were found</p>
              <p>Make sure your keywords are spelled correctly</p>
              <p>Try different keywords</p>
              <p>Try more general keywords</p>
              <p>Try removing your most recent keyword</p>
            </div>
          ) : null}

          {
          resultsData.length === 1 && resultsData[0]['error'] === "Result set was empty" ? (null) :
            <table>
              {
                isData && resultsData.length ? (
              <thead>
                <tr>
                  <td>Document Title</td>
                  <td>Author</td>
                  <td>Publication Name</td>
                  <td>DOI</td>
                  <td>Citation</td>
                </tr>
              </thead>
                ) : null
}
              <tbody>
                {resultsData.map((result, i) => (
                  <tr key={i}>
                    <td>
                      <a
                        href={result['link']?.[2]?.['@href']}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {result['dc:title']}
                      </a>
                    </td>
                    <td>{result['dc:creator']}</td>
                    <td>{result['prism:publicationName']}</td>
                    <td>{result['prism:doi']}</td>
                    <td>{result['citedby-count']}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          }
        </div>
      </div>
      <Footer className="footer-panel"/>
    </>
  );
};

export default Home;
