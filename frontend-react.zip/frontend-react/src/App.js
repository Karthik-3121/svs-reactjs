import React, { useState } from 'react';
import { Home } from './components/HomeScreen';
import { ScopusSearch } from './api/ScopusSearch';

const App = (props) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchData, setSearchData] = useState({});
  const setSearch = async (term) => {
    setSearchTerm(term);
    await setData(term);
  };
  const setData = async (term) => {
    const searches = await ScopusSearch(term);
    setSearchData(searches);
    console.log(JSON.parse(searches));
  };
  return (
    <Home 
      setSearch={setSearch}
      setData={searchData}
    />
  );
};

export default App;
