import axios from 'axios';

export const ScopusSearch = async (term) => {
  const { data } = await axios.get(
    //Scopus API
    'http://127.0.0.1:8000/scopus',
    {
      params: {
        query: term,
      },
    }
  );
  return data;
};
